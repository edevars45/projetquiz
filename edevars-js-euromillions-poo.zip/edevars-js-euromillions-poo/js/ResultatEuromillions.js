export default class ResultatEuromillions {
    // Définit une classe nommée ResultatEuromillions qui sera exportée par défaut.
    comparerTirage(tirage, choixJoueur) {
        // Définit une méthode pour comparer le résultat du tirage avec les choix du joueur.
        const numerosCorrects = tirage.numeros.filter(numero => choixJoueur.numeros.includes(numero)).length;
        // Filtre le tableau des numéros tirés et ne garde que ceux qui sont présents dans le tableau des numéros choisis par le joueur. Ensuite, on compte le nombre de ces numéros.
        const etoilesCorrectes = tirage.etoiles.filter(etoile => choixJoueur.etoiles.includes(etoile)).length;
        // Filtre le tableau des étoiles tirées et ne garde que celles qui sont présentes dans le tableau des étoiles choisies par le joueur. Ensuite, on compte le nombre de ces étoiles.
        return { numerosCorrects, etoilesCorrectes };
        // Retourne un objet contenant le nombre de numéros et d'étoiles corrects.
    }
}