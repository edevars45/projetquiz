export default class AffichageResultat {
    // Définit une classe nommée AffichageResultat qui sera exportée par défaut.
    afficherResultats(tirageResultat, comparaisonResultat, numerosTirageElement, etoilesTirageElement, numerosCorrectsElement, etoilesCorrectsElement, resultatsDiv) {
        // Définit une méthode pour afficher les résultats dans l'interface utilisateur.
        numerosTirageElement.textContent = tirageResultat.numeros.join(' - ');
        // Met le contenu de l'élément HTML pour les numéros tirés avec les numéros du résultat, séparés par " - ".
        etoilesTirageElement.textContent = tirageResultat.etoiles.join(' - ');
        // Met le contenu de l'élément HTML pour les étoiles tirées avec les étoiles du résultat, séparées par " - ".
        numerosCorrectsElement.textContent = comparaisonResultat.numerosCorrects;
        // Met le contenu de l'élément HTML pour les numéros corrects avec le nombre de numéros corrects.
        etoilesCorrectsElement.textContent = comparaisonResultat.etoilesCorrectes;
        // Met le contenu de l'élément HTML pour les étoiles correctes avec le nombre d'étoiles correctes.
        resultatsDiv.classList.remove('hidden');
        // Supprime la classe 'hidden' de la div des résultats pour la rendre visible.
    }
}