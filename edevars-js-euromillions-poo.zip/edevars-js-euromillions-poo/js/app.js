// Importations des classes depuis leurs fichiers respectifs.
import GenerateurAleatoire from './GenerateurAleatoire.js';
import TirageEuromillions from './TirageEuromillions.js';
import JoueurEuromillions from './JoueurEuromillions.js';
import ResultatEuromillions from './ResultatEuromillions.js';
import AffichageResultat from './AffichageResultat.js'; // Importe la classe pour l'affichage des résultats.

// Instanciation des classes, création d'objets à partir des classes.
const tirage = new TirageEuromillions();
// Crée une instance de la classe TirageEuromillions pour effectuer le tirage.
const joueur = new JoueurEuromillions();
// Crée une instance de la classe JoueurEuromillions pour gérer les choix du joueur.
const resultat = new ResultatEuromillions();
// Crée une instance de la classe ResultatEuromillions pour comparer les résultats.
const affichage = new AffichageResultat();
// Crée une instance de la classe AffichageResultat pour afficher les résultats dans l'interface utilisateur.

// Récupération des éléments HTML du document en utilisant leurs IDs ou des sélecteurs CSS.
const numeroInputs = document.querySelectorAll('#selection-joueur input[id^="numero"]');
// Sélectionne tous les inputs dont l'ID commence par "numero" dans la section de sélection du joueur.
const etoileInputs = document.querySelectorAll('#selection-joueur input[id^="etoile"]');
// Sélectionne tous les inputs dont l'ID commence par "etoile" dans la section de sélection du joueur.
const boutonJouer = document.getElementById('jouer');
// Sélectionne le bouton avec l'ID "jouer".
const resultatsDiv = document.getElementById('resultats');
// Sélectionne la div avec l'ID "resultats" (initialement cachée).
const numerosTirageElement = document.getElementById('numeros-tirage');
// Sélectionne l'élément où afficher les numéros du tirage.
const etoilesTirageElement = document.getElementById('etoiles-tirage');
// Sélectionne l'élément où afficher les étoiles du tirage.
const numerosCorrectsElement = document.getElementById('numeros-corrects');
// Sélectionne l'élément où afficher le nombre de numéros corrects.
const etoilesCorrectsElement = document.getElementById('etoiles-corrects');
// Sélectionne l'élément où afficher le nombre d'étoiles correctes.

function recupererChoixJoueur() {
    // Fonction pour récupérer les numéros et étoiles choisis par le joueur depuis les inputs.
    const numerosChoisis = Array.from(numeroInputs)
        // Convertit la NodeList des inputs de numéros en un tableau.
        .map(input => parseInt(input.value))
        // Convertit la valeur de chaque input en un nombre entier.
        .filter(nombre => !isNaN(nombre) && nombre >= 1 && nombre <= 50);
        // Filtre pour ne garder que les nombres valides (entre 1 et 50).

    const etoilesChoisies = Array.from(etoileInputs)
        // Convertit la NodeList des inputs d'étoiles en un tableau.
        .map(input => parseInt(input.value))
        // Convertit la valeur de chaque input en un nombre entier.
        .filter(nombre => !isNaN(nombre) && nombre >= 1 && nombre <= 12);
        // Filtre pour ne garder que les nombres valides (entre 1 et 12).

    return { numeros: numerosChoisis, etoiles: etoilesChoisies };
    // Retourne un objet contenant les tableaux des numéros et étoiles choisis.
}

boutonJouer.addEventListener('click', () => {
    // Ajoute un écouteur d'événements au clic du bouton "Valider mes numéros".
    const choixJoueur = recupererChoixJoueur();
    // Récupère les numéros et étoiles choisis par le joueur.

    if (choixJoueur.numeros.length === 5 && choixJoueur.etoiles.length === 2) {
        // Vérifie si le joueur a sélectionné exactement 5 numéros et 2 étoiles.
        joueur.choisirNumeros(choixJoueur.numeros);
        // Enregistre les numéros choisis par le joueur dans l'objet joueur.
        joueur.choisirEtoiles(choixJoueur.etoiles);
        // Enregistre les étoiles choisies par le joueur dans l'objet joueur.

        const tirageResultat = tirage.effectuerTirage();
        // Effectue le tirage de l'Euromillions et stocke le résultat.
        const comparaisonResultat = resultat.comparerTirage(tirageResultat, joueur.obtenirChoix());
        // Compare le résultat du tirage avec les choix du joueur.

        affichage.afficherResultats(tirageResultat, comparaisonResultat, numerosTirageElement, etoilesTirageElement, numerosCorrectsElement, etoilesCorrectsElement, resultatsDiv);
        // Affiche les résultats dans l'interface utilisateur en utilisant l'objet affichage.
    } else {
        // Si le nombre de numéros ou d'étoiles choisis n'est pas correct, affiche une alerte.
        alert("Veuillez sélectionner 5 numéros et 2 étoiles valides.");
    }
});

// Afficher un tirage initial au chargement de la page (optionnel).
const tirageInitial = tirage.effectuerTirage();
numerosTirageElement.textContent = tirageInitial.numeros.join(' - ');
etoilesTirageElement.textContent = tirageInitial.etoiles.join(' - ');