class ResultatEuromillions {
    constructor(numeros, etoiles) {
        this.numeros = numeros;
        this.etoiles = etoiles;
    }

    getNumeros() {
        return this.numeros;
    }

    getEtoiles() {
        return this.etoiles;
    }
}
export default ResultatEuromillions;