class Male extends Fourmi {
    constructor(age, taille) {
        super(age, taille);
    }

    feconder() {
        console.log("Méthode feconder() de Male");
    }

    voler() {
        console.log("Méthode voler() de Male");
    }
}