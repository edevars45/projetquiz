class Femelle extends Fourmi {
    constructor(age, taille){
        super(age, taille);
    }

    chercherNourriture() {
        console.log("Méthode chercherNourriture() de Femelle");
    }
}