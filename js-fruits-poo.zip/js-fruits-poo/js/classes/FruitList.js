class FruitList
{
    #tabFruits;
    #idDivFruits;
    #idImageToChange;
    #list = [];

    constructor(tabFruits, idDivFruits = "fruits", idImageToChange = "imageFruit")
    {
        this.#tabFruits = tabFruits;
        this.#idDivFruits = idDivFruits;
        this.#idImageToChange = idImageToChange;

        this.#createFruitList();
    }

    get list()
    {
        return this.#list;
    }

    #createFruitList()
    {
        const divFruits = document.querySelector(`#${this.#idDivFruits}`);
        const imageTochange = document.querySelector(`#${this.#idImageToChange}`);
        const btnHeight = 100 / this.#tabFruits.length;
        
        
        this.#tabFruits.forEach(fruit => {
            const btnFruit = new Fruit(fruit.name, fruit.image, imageTochange, btnHeight);
            this.#list.push(btnFruit);
            divFruits.appendChild(btnFruit.html);
        });
    }
}