class Fruit 
{
    #name; /* orange */
    #image; /* orange.jpeg */
    #bgColor; /* #FF0000 */
    #html; /* <div class="boutonFruit">Orange</div> */
    #height;
    #zoneImage;

    static #imageSelected = "all-fruits.jpg";

    constructor(name, image, zoneImage, height = 100, bgColor = "#FF0000")
    {
        console.log("constructeur Fruit")
        this.name = name;
        this.image = image;
        this.#zoneImage = zoneImage;
        this.#height = height;
        this.bgColor = bgColor;
        this.createButton();
    }

    get name()
    {
        return this.#name;
    }

    set name(name)
    {
        this.#name = name;
    }

    get image()
    {
        return this.#image
    }

    set image(image)
    {
        this.#image = image;
    }

    get height()
    {
        return this.#height;
    }

    get bgColor()
    {
        return this.#bgColor;
    }

    set bgColor(color)
    {
        this.#bgColor = color;
    }

    get html()
    {
        return this.#html;
    }

    createButton()
    {
        console.log("createButton");
        this.#html = document.createElement("div");
        this.#html.textContent = this.name;
        this.#html.classList.add("boutonFruits");
        this.#html.style.height = this.height + "vh";

        this.#html.addEventListener('mouseover', (event) => {
            this.#zoneImage.style.backgroundImage = `url(./images/${this.image})`;
        });

        this.#html.addEventListener('mouseout', (event) => {
            console.log("mouseout image :", Fruit.#imageSelected);
            this.#zoneImage.style.backgroundImage = `url(./images/${Fruit.#imageSelected}`;
        });

        this.#html.addEventListener('click', (event) => {
            Fruit.#imageSelected = this.image;
            console.log("click image :",Fruit.#imageSelected);
            this.#zoneImage.style.backgroundImage = `./images/url(${Fruit.#imageSelected}`;
            const allFruits = document.querySelectorAll(".boutonFruits");
            allFruits.forEach(fruitDiv => {
                fruitDiv.style.backgroundColor = "";
            });
            this.#html.style.backgroundColor = "red";
        });
    }
}