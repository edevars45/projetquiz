const fruits = [
    { name: "Orange", image: "orange.jpg" }, 
    { name: "Kiwi", image: "kiwi.jpg" }, 
    { name: "Banane", image: "banane.jpg" }, 
    { name: "Peche", image: "peche.jpg" }, 
    { name: "Cerise", image: "cerise.jpg" }
];

const fruitList = new FruitList(fruits, "fruits", "imageFruit");

console.log(fruitList.list);